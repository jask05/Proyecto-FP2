<!--Secondary Navigation-->
<nav id="secondary_nav"> 
<!--UserInfo-->
<dl class="user_info">
	<dt><a href="#"><img src="./images/avatar.png" alt="" /></a></dt>
    <dd>
    <a class="welcome_user" href="#">Bienvenido,<strong> <?php echo $user; ?></strong></a>
    <!-- <span class="log_data">Last sign in : 16:11 Feb 27th 2012</span> -->
    <a class="logout" href="logout.php">Salir</a>
    <!-- <a class="user_messages" href="#"><span>12</span></a> -->
    </dd>
</dl>
<!--
<h2>Panel</h2>
<ul>
    <li><a href="#"><span class="iconsweet">a</span>User Profiles</a></li>

    <li><a href="#"><span class="iconsweet">k</span>Administración</a></li>
    <li><a href="#"><span class="iconsweet">o</span>Milestornes</a></li>
    <li><a href="#"><span class="iconsweet">S</span>Worklog</a></li>
</ul>
-->
</nav>